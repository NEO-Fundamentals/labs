NEO_Diagnostics — Wireshark profile
NEO Fundamentals · Wireshark for Troubleshooting.

Built and checked with TShark (Wireshark) 4.4.18 on 2026-11-17 (America/Los_Angeles).
This profile does not require a live capture.

What it contains
- colorfilters: DNS errors, TCP zero window, TCP RST, retransmission, high delta time (frame.time_delta > 1), then SYN/FIN, TCP, UDP, ICMP, ARP. First match wins.
- preferences: Delta (frame.time_delta, the gap to the previous frame in the file), source port, destination port, and TCP window columns. Name resolution off.
- dfilter_buttons: RST, Retrans, ZeroWin, DNS err, High delta, TCP analysis, SYNs.
- dfilters and cfilters: the same expressions saved by name.

How to import
1. In Wireshark: Edit → Configuration Profiles… → Import → choose this zip.
   The zip contains a folder named NEO_Diagnostics.
2. Or unzip into your personal profiles directory, then select NEO_Diagnostics:
   - Linux / macOS: ~/.config/wireshark/profiles/
   - Windows: %APPDATA%\Wireshark\profiles\
3. Switch to NEO_Diagnostics and open a capture.

Colors (what you see in the packet list)
Wireshark's colorfilters file lists the BACKGROUND color first, then the FOREGROUND (text) color.
- DNS errors: pink background, dark text
- TCP Zero Window: coral background, dark text
- TCP RST: yellow background, dark text
- Retransmission: orange background, dark text
- High delta time: blue background, dark text
- TCP SYN/FIN: dark grey background, light text
- TCP: dark blue background, light text
- UDP: dark slate background, light text
- ICMP: lavender background, dark text
- ARP: light grey-beige background, dark text
Fault rows (DNS errors, zero window, RST, retransmission) are warm and bright, and a gap of more than one second is light blue; these rules are listed first, so they win.
TCP and UDP rows are dark with light text. ARP and ICMP rows are light (beige and lavender) with dark text: they are normal traffic, not faults.
Checked in Wireshark 4.4.19 on 2026-11-20; legend re-checked with TShark 4.2.2 on 2026-11-24.

Notes
- High delta and the Delta column both use frame.time_delta (the gap to the previous frame in the file), not frame.time_delta_displayed, so a display filter or button does not change the gap you see.
- First match wins: a frame takes the color of the first rule it matches. A retried SYN more than one second after the last frame matches both Retransmission and High delta, and shows the Retransmission color because that rule is listed first.
- DNS error coloring was checked on a short DNS file generated for this lesson (not from the TCP lab topology). The TCP lab files have no DNS.
- Checked against the TCP lab captures used in the TCP Basics and TCP Troubleshooting lessons.
